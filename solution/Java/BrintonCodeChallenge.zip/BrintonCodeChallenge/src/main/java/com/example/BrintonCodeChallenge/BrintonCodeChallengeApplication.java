package com.example.BrintonCodeChallenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrintonCodeChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrintonCodeChallengeApplication.class, args);
	}

}
